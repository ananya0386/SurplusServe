# food-donate

<p>  The basic concept of this project  Food Waste Management is to collect theexcess/leftover food from donors such as hotels, restaurants, marriage halls, etc and distribute to  the  needy people .</p>
<h3>features:</h3>
<ul><li>Mobile Screen friendly website.</li>
  <li>chatbot support</li>
  <li>User Authentication.</li>
  </ul>


<h2>Mobile Screen friendly website.</h2>
<img src="img/mobile.jpg" >
<h2>chatbot support</h2>
<img src="img/chatbotsupport.jpg">

<h2>View demo</h2>
<a href="https://vimeo.com/844273515">click here</a>

